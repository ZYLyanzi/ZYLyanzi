export default {
	host: 'localhost:8080',
	timeout: 10000
}