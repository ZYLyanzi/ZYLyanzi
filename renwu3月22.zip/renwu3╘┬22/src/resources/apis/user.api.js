export default {
    userLogin: '/user/userLogin',
    userRegister: '/user/userRegister',
    queryUserInfo: '/user/queryUserInfo',
	updateUserInfo: '/user/updateUserInfo',

}
