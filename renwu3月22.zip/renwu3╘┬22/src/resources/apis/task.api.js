export default {
	queryTaskType: '/task/queryTaskType',
	addTask: '/task/addTask',
	taskDesc: '/task/taskDesc',
	updateTask: '/task/updateTask',

}
