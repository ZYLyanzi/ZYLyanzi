export default {
	getList: '/product/getList',
	getInfo: '/product/getInfo'
}